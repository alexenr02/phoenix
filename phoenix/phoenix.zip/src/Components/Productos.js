import React from 'react'
/*
import image1 from "../imgs/zap1.png";
import image2 from "../imgs/zap2.jfif";
import image3 from "../imgs/zap3.jfif";
import image4 from "../imgs/Zap4.jfif";
*/


import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../../node_modules/bootstrap-icons/font/bootstrap-icons.css";

import ListImg from './ListImg';




function Productos() {
  return (
    <div id='centro' >

       <ListImg />
    </div>
  )
}

export default Productos