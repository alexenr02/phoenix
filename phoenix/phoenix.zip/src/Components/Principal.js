import React from 'react'
import NavBar from './NavBar';

function Principal() {
  return (
    <div>
      <p>Principal</p>

    </div>
  )
}

export default Principal