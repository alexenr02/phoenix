import React from 'react'

function Carrito() {
  return (
    <div>
        <p>Carrito</p>
    </div>
  )
}

export default Carrito